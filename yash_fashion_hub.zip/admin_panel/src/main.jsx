import React from "react";
import { createRoot } from 'react-dom/client';
createRoot(document.getElementById('root')).render(<div style={{padding:20}}><h2>Yash Admin (placeholder)</h2></div>);